"""
Expose version
"""

__version__ = "1.3.4"
VERSION = __version__.split('.')
